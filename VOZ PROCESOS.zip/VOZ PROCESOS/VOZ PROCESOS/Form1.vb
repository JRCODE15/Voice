﻿Imports System.Speech.Recognition


Public Class Form1

    Dim REC As New SpeechRecognitionEngine
    Dim PALABRA As String

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        REC.SetInputToDefaultAudioDevice()
        Dim VOCABULARIO As New GrammarBuilder
        VOCABULARIO.Append(New Choices("abre el navegador", "abre el word", "abre el paint"))
        REC.LoadGrammar(New Grammar(VOCABULARIO))
        REC.RecognizeAsync(RecognizeMode.Multiple)
        AddHandler REC.SpeechRecognized, AddressOf RECONOCE
        AddHandler REC.SpeechRecognitionRejected, AddressOf NORECONOCE
    End Sub

    Public Sub RECONOCE(ByVal sender As Object, ByVal e As SpeechRecognizedEventArgs) 
        Dim RESULTADO As RecognitionResult = e.Result
        Label1.Text = RESULTADO.Text.ToUpper
        Dim PROCESO As New Process
        Select Case RESULTADO.Text

            Case "abre el navegador"
                PROCESO.StartInfo.FileName = "C:\Program Files (x86)\Mozilla Firefox\firefox.exe"
                PROCESO.Start()
            Case "abre el word"
                PROCESO.StartInfo.FileName = "C:\Program Files\Windows NT\Accessories\wordpad.exe"
                PROCESO.Start()
            Case "abre el paint"
                PROCESO.StartInfo.FileName = "C:\Windows\System32/mspaint.exe"
                PROCESO.Start()
        End Select

    End Sub

    Public Sub NORECONOCE()
        Label1.Text = "REPITE, POR FAVOR"
    End Sub

End Class
